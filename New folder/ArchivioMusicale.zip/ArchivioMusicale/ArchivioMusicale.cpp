
#include "ArchivioMusicale.h"

/*
Sia A l'autore che ha scritto piu' album nell'archivio musicale.
(Se piu' autori hanno questa proprieta', prendere il primo
di questi che compare nell'archivio musicale.) 
Restituire la somma dei prezzi di tutti i album scritti da A.

Se non sono presenti album nell'archivio musicale, restituire -1.
            
*/
int ArchivioMusicale::metodo1()
{
    /* IMPLEMENTARE QUESTO METODO */
    return -1;
}

/*
Determinare la mediana degli album ottenuta considerando la seguente relazione d'ordine: 

Un album A1 precede un album A2 se il prezzo di A1 e' minore del prezzo di A2 e a parita' di prezzo, il tipo di A1 precede il tipo di A2 (POP precede ROCK precede CLASSICA).

Restituire il prezzo dell'album che si trova in corrispondenza della mediana.

Nel caso in cui non ci siano album presenti nell'archivio musicale, restituire -1.

NOTA BENE: calcolare mediana nel seguente modo: dopo aver ordinato gli oggetti in modo crescente,
si prende quello presente nel mezzo (utilizzare la divisione intera: size/2). 
            
*/
int ArchivioMusicale::metodo2()
{
    /* IMPLEMENTARE QUESTO METODO */
    return -1;
}

/*
Data la seguente definizione: 
Un album A1 e' collegato un album A2 se:
- A1 e' collegato a A2, oppure
- A1 e' collegato a A3 e A3 e' collegato a A2.

Sia A l'album con il piu' alto numero di collegamenti, il metodo deve restituire il numero di album con cui A e' collegato.

Nel caso in cui non ci siano album nell'archivio musicale restituisce -1.
            
*/
int ArchivioMusicale::metodo3()
{
    /* IMPLEMENTARE QUESTO METODO */
    return -1;
}

/*
Data la seguente definizione:
Un album A1 e' collegato ad un album A2 se:
- A1 e' collegato a A2, oppure
- A1 e' collegato a A3 e A3 e' collegato A2.

Sia A il primo album dell'archivio musicale, il metodo deve restituire il numero di album con cui A e' collegato.

Nel caso in cui non ci siano album nell'archivio musicale restituisce -1.
            
*/
int ArchivioMusicale::metodo4()
{
    /* IMPLEMENTARE QUESTO METODO */
    return -1;
}


