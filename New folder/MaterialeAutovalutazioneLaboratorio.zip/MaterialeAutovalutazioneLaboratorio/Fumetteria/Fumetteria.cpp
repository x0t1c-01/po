
#include "Fumetteria.h"

/*
Sia A l'autore che ha scritto piu' fumetti nella fumetteria.
(Se piu' autori hanno questa proprieta', prendere il primo
di questi che compare nella fumetteria.) 
Restituire la somma dei prezzi di tutti i fumetti scritti da A.

Se non sono presenti fumetti nella fumetteria, restituire -1.
            
*/
int Fumetteria::metodo1()
{
    /* IMPLEMENTARE QUESTO METODO */
    return -1;
}

/*
Determinare la mediana dei fumetti ottenuta considerando la seguente relazione d'ordine: 

Un fumetto F1 precede un fumetto F2 se il prezzo di F1 e' minore del prezzo di F2 e a parita' di prezzo, il tipo di F1 precede il tipo di F2 (KODOMO precede SPOKON precede GEKIGA).

Restituire il prezzo del fumetto che si trova in corrispondenza della mediana.

Nel caso in cui non ci siano fumetti presenti nella fumetteria, restituire -1.

NOTA BENE: calcolare mediana nel seguente modo: dopo aver ordinato gli oggetti in modo crescente,
si prende quello presente nel mezzo (utilizzare la divisione intera: size/2). 
            
*/
int Fumetteria::metodo2()
{
    /* IMPLEMENTARE QUESTO METODO */
    return -1;
}

/*
Data la seguente definizione: 
Un fumetto F1 fa riferimento ad un fumetto F2 se:
- F1 fa riferimento a F2, oppure
- F1 fa riferimento a F3 e F3 fa riferimento a F2.

Sia F il fumetto con il piu' alto numero di riferimenti, il metodo deve restituire il numero di fumetti a cui F fa riferimento.

Nel caso in cui non ci siano fumetti nella fumetteria restituisce -1.
            
*/
int Fumetteria::metodo3()
{
    /* IMPLEMENTARE QUESTO METODO */
    return -1;
}

/*
Data la seguente definizione:
Un fumetto F1 fa riferimento ad un fumetto F2 se:
- F1 fa riferimento a F2, oppure
- F1 fa riferimento a F3 e F3 fa riferimento a F2.

Sia F il primo fumetto della fumetteria, il metodo deve restituire il numero di fumetti con cui F fa riferimento.

Nel caso in cui non ci siano fumetti nella fumetteria restituisce -1.
            
*/
int Fumetteria::metodo4()
{
    /* IMPLEMENTARE QUESTO METODO */
    return -1;
}


