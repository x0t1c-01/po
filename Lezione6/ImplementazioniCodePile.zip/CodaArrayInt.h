#ifndef CODA_ARRAY_INT_H
#define CODA_ARRAY_INT_H

#include <iostream>
using namespace std;

class CodaArrayInt {
    public:
		CodaArrayInt();
		CodaArrayInt(const CodaArrayInt& p);
		~CodaArrayInt();
		CodaArrayInt& operator=(const CodaArrayInt& p);
        bool empty() const;
        unsigned int size() const;
        int front();
        int back();
        void push(int elem);
        void pop();
		void print() const;

    private:
        unsigned int capacity;
		unsigned int sz;
		int* elements;		
};

#endif