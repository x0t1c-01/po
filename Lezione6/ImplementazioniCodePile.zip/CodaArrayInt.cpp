#include "CodaArrayInt.h"

CodaArrayInt::CodaArrayInt(){
	capacity=1;
	sz=0;
	elements=new int[capacity];
}

CodaArrayInt::CodaArrayInt(const CodaArrayInt& p){
	capacity=p.capacity;
	sz=p.sz;
	elements=new int[capacity];
	for(unsigned i=0;i<sz;i++)
		elements[i]=p.elements[i];
}

CodaArrayInt::~CodaArrayInt(){
	delete [] elements;
}

CodaArrayInt& CodaArrayInt::operator=(const CodaArrayInt& p){
	if(this!=&p){
		if(capacity<p.capacity){
			delete [] elements;
			capacity=p.capacity;
			elements=new int[capacity];
		}
		sz=p.sz;
		for(unsigned i=0;i<sz;i++)
			elements[i]=p.elements[i];
	}
	return *this;
}

bool CodaArrayInt::empty() const {
	return sz==0;
}

unsigned int CodaArrayInt::size() const {
	return sz;
}

int CodaArrayInt::front() {
	if(sz>0) 
		return elements[0]; 
	return 0;
}

int CodaArrayInt::back() {
	if(sz>0) 
		return elements[sz-1]; 
	return 0;
}

void CodaArrayInt::push(int elem){
	if(sz==capacity){
		capacity*=2;
		int* tmp=new int[capacity];
		for(unsigned i=0;i<sz;i++)
			tmp[i]=elements[i];
		delete [] elements;
		elements=tmp;
	}
	elements[sz]=elem;
	sz++;
}

void CodaArrayInt::pop(){
	if(sz>0){
		sz--;
		for(unsigned i=0;i<sz;i++)
			elements[i]=elements[i+1];
	}
}

void CodaArrayInt::print() const {
	for(int i=0;i<sz;i++)
		cout<<elements[i]<<" ";
	cout<<endl;
}