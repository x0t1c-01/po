#include "PilaArrayInt.h"

PilaArrayInt::PilaArrayInt(){
	capacity=1;
	sz=0;
	elements=new int[capacity];
}

PilaArrayInt::PilaArrayInt(const PilaArrayInt& p){
	capacity=p.capacity;
	sz=p.sz;
	elements=new int[capacity];
	for(unsigned i=0;i<sz;i++)
		elements[i]=p.elements[i];
}

PilaArrayInt::~PilaArrayInt(){
	delete [] elements;
}

PilaArrayInt& PilaArrayInt::operator=(const PilaArrayInt& p){
	if(this!=&p){
		if(capacity<p.capacity){
			delete [] elements;
			capacity=p.capacity;
			elements=new int[capacity];
		}
		sz=p.sz;
		for(unsigned i=0;i<sz;i++)
			elements[i]=elements[i];
	}
	return *this;
}

bool PilaArrayInt::empty() const {
	return sz==0;
}

unsigned int PilaArrayInt::size() const {
	return sz;
}

int PilaArrayInt::front() {
	if(sz>0) 
		return elements[0]; 
	return 0;
}

int PilaArrayInt::back() {
	if(sz>0) 
		return elements[sz-1]; 
	return 0;
}

void PilaArrayInt::push(int elem){
	if(sz==capacity){
		capacity*=2;
		int* tmp=new int[capacity];
		for(unsigned i=0;i<sz;i++)
			tmp[i]=elements[i];
		delete [] elements;
		elements=tmp;
	}
	elements[sz]=elem;
	sz++;
}

void PilaArrayInt::pop(){
	if(sz>0)
		sz--;
}

void PilaArrayInt::print() const {
	for(int i=0;i<sz;i++)
		cout<<elements[i]<<" ";
	cout<<endl;
}