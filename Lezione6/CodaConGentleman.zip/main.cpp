#include "CodaConGentleman.h"

int main(){
	Persona u1(true);
	Persona d1(false);
	Persona d2(false);
	Persona u2(true);
	Persona u3(true);
	Persona d3(false);
	CodaConGentleman c;
	c.push(u1);
	c.push(d1);
	c.push(d2);
	c.push(u2);
	c.push(u3);
	c.push(d3);
	cout<<"La coda contiene:"<<endl;
	c.stampa();
	while(!c.empty())
	{
		c.pop();
		cout<<"Dopo pop la coda contiene:"<<endl;
		c.stampa();
	}
	return 0;
}