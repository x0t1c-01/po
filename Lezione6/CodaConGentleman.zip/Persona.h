#ifndef PERSONA_H_
#define PERSONA_H_

class Persona {
public:
	Persona(bool u):uomo(u){};
	bool isUomo() const {
		return uomo;
	}
private:
	bool uomo;

};

#endif
