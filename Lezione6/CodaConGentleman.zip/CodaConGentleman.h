#ifndef CODACONGENTLEMAN_H_
#define CODACONGENTLEMAN_H_

#include <iostream>
#include <list>
#include "Persona.h"
using namespace std;

class CodaConGentleman {
public:
	void push(const Persona& p);
	void pop();
	unsigned size();
	bool empty();
	void stampa() const;
private:
	list<Persona> persone;
};
#endif