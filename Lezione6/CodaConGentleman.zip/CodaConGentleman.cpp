#include "CodaConGentleman.h"

void CodaConGentleman::push(const Persona& p) {
	persone.push_back(p);
}

void CodaConGentleman::pop() {
	if(persone.size()>1){
		list<Persona>::iterator it1=persone.begin();
		list<Persona>::iterator it2=it1++;
		if(it1->isUomo() && !it2->isUomo())
			persone.erase(it2);
		else
			persone.erase(it1);
	}
	else
		persone.pop_front();
}

unsigned CodaConGentleman::size() {
	return persone.size();
}

bool CodaConGentleman::empty() {
	return persone.empty();
}

void CodaConGentleman::stampa() const {
	for(list<Persona>::const_iterator it=persone.begin();it!=persone.end();++it)
		if((*it).isUomo())
			cout<<"U ";
		else
			cout<<"D ";
	cout<<endl;
}
