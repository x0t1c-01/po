#ifndef PILA_ARRAY_H
#define PILA_ARRAY_H

#include <iostream>
using namespace std;

template <class T>
class PilaArray {
    public:
		PilaArray(){
			capacity=1;
			sz=0;
			elements=new T[capacity];
		}

		PilaArray(const PilaArray& p){
			capacity=p.capacity;
			sz=p.sz;
			elements=new T[capacity];
			for(unsigned i=0;i<sz;i++)
				elements[i]=p.elements[i];
		}

		~PilaArray(){
			delete [] elements;
		}

		PilaArray& operator=(const PilaArray& p){
			if(this!=&p){
				if(capacity<p.capacity){
					delete [] elements;
					capacity=p.capacity;
					elements=new T[capacity];
				}
				sz=p.sz;
				for(unsigned i=0;i<sz;i++)
					elements[i]=elements[i];
			}
			return *this;
		}

		bool empty() const {
			return sz==0;
		}

		unsigned int size() const {
			return sz;
		}

		T front() {
			if(sz>0) 
				return elements[0]; 
			return 0;
		}

		T back() {
			if(sz>0) 
				return elements[sz-1]; 
			return 0;
		}

		void push(T elem){
			if(sz==capacity){
				capacity*=2;
				T* tmp=new T[capacity];
				for(unsigned i=0;i<sz;i++)
					tmp[i]=elements[i];
				delete [] elements;
				elements=tmp;
			}
			elements[sz]=elem;
			sz++;
		}

		void pop(){
			if(sz>0)
				sz--;
		}

		void print() const {
			for(int i=0;i<sz;i++)
				cout<<elements[i]<<" ";
			cout<<endl;
		}

    private:
        unsigned int capacity;
		unsigned int sz;
		T* elements;		
};

#endif