#ifndef PILA_LIST_H
#define PILA_LIST_H

#include <list>
#include <iostream>
using namespace std;

template <class T>
class PilaList {
	public:
		bool empty() const{
			return elements.empty();
		}
		unsigned int size() const {
			return elements.size();
		}
		T front(){
			return elements.front();
		}
		T back(){
			return elements.back();
		}
		void push(T elem){
			elements.push_back(elem);
		}
		void pop(){
			if(!empty())
				elements.pop_back();
		}
		void print() const{
			for(typename list<T>::const_iterator it=elements.begin();it!=elements.end();it++)
				cout<<*it<<" ";
			cout<<endl;
			/* NB: Chiarimento sul typename, che se omesso porta ad errori di compilazione:
				Il tipo degli elementi su cui l'iteratore si troverà ad iterare dipende dalla classe template T.
				Senza typename il compilatore (g++) suppone che esista una qualche classe che si chiama proprio T 
				e che la lista sia una lista di oggetti di questa ipotetica classe T.
				Quando in fase di compilazione g++ non trova la definizione della classe T segnala un errore.
				Tuttavia mettendo typename davanti all'iteratore specifichiamo che si tratta di una classe template,
				non di una classe che abbiamo realmente implementato e che ha nome T e la compilazione va a buon fine.
			*/
		}
		
    private:
        list<T> elements;
};

#endif