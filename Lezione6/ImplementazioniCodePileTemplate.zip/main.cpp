#include "CodaList.h"
#include "PilaList.h"
#include "CodaArray.h"
#include "PilaArray.h"

int main(){
	PilaArray<int> l;
	l.push(1);
	l.push(2);
	l.push(3);
	l.push(4);
	l.push(5);
	l.print();
	
	l.pop();
	l.print();
	
	l.push(6);
	l.print();
	
	cout<<"FRONT: "<<l.front()<<endl;
	cout<<"BACK: "<<l.back()<<endl;
	
	return 0;
}