#ifndef PILA_LIST_CHAR_H
#define PILA_LIST_CHAR_H

#include <list>
#include <iostream>
using namespace std;

class PilaListChar {
    public:
        bool empty() const;
        unsigned int size() const;
        char front();
        char back();
        void push(char elem);
        void pop();
		void print() const;

    private:
        list<char> elements;
		
};

#endif