#include "PilaListChar.h"

int main(){
	PilaListChar p;
	char c;
	cin>>c;
	bool ok=true;
	while(c!='.'){
		if(c=='(')
			p.push(c);
		if(c==')'){
			if(p.empty())
				ok=false;
			p.pop();
		}
		cin>>c;
	}
	if(p.empty() && ok)
		cout<<"OK"<<endl;
	else
		cout<<"NO"<<endl;	
	return 0;
}