#include "PilaListChar.h"

bool PilaListChar::empty() const {
	return elements.empty();
}

unsigned int PilaListChar::size() const {
	return elements.size();
}

char PilaListChar::front() {
	return elements.front();
}

char PilaListChar::back() {
	return elements.back();
}

void PilaListChar::push(char elem){
	elements.push_back(elem);
}

void PilaListChar::pop(){
	if(!empty())
		elements.pop_back();
}

void PilaListChar::print() const {
	for(list<char>::const_iterator it=elements.begin();it!=elements.end();it++)
		cout<<*it<<" ";
	cout<<endl;
}