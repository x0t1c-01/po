#include "Professore.h"
#include "Studente.h"
#include <list>

int main(){
	Studente studente;
	Professore prof;

	//Valido, da superclassi a sottoclassi
	/*Persona* p1=new Studente;
	Persona* p2=new Professore;
	delete p1;
	delete p2;
	p1=&studente;
	p2=&prof;*/
	
	//Non valido, da sottoclassi a superclassi
	//Studente* studente2=new Persona;
	//Professore* prof2=new Persona;
	
	//E' possibile costruire stutture dati che contengano puntatori alla classe base
	/*list<Persona*> persone;
	persone.push_back(p1);
	persone.push_back(p2);*/
	/*Persona** array=new Persona*[10];
	array[0]=p1;
	array[1]=p2;
	delete [] array;*/
	
	//Valido, ma dobbiamo essere certi che il cast sia lo stesso dell'oggetto puntato
	//Studente* p3=(Studente*)(p1);
	//cout<<p3->getIsee()<<endl;
	
	//Non valido, attenzione: undefined behaviour
	//Professore* p3=(Professore*)(p1); 
	//cout<<p3->getStipendio()<<endl;
	
	//Non valido p1 è una Persona --> ne riparleremo prossimamente, quando tratteremo il polimorfismo
	//cout<<p1->getIsee()<<endl;
	
	return 0;
}
