#include "CodaListInt.h"
#include "CodaEreditaListInt.h"
#include "CodaPrioritaInt.h"
#include "CodaPrioritaIntVersione2.h"

int main(){
	CodaListInt l;
	l.push(4);
	l.push(3);
	l.push(4);
	l.push(3);
	l.push(2);
	l.push(1);
	l.print();
	
	l.pop();
	l.print();
	
	l.push(2);
	l.print();
	
	cout<<"FRONT: "<<l.front()<<endl;
	cout<<"BACK: "<<l.back()<<endl;
	
	return 0;
}