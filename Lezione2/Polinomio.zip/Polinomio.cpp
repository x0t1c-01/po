#include "Polinomio.h"

Polinomio::Polinomio(unsigned int grado):dimensione(grado+1){
	array=new int[dimensione];
	for(int i=0;i<dimensione;i++)
		array[i]=0;
}

Polinomio::Polinomio(const Polinomio& p):dimensione(p.dimensione){
	array=new int[dimensione];
	for(int i=0;i<dimensione;i++)
		array[i]=p.array[i];
}

Polinomio& Polinomio::operator=(const Polinomio& p){
	if(this!=&p){ //p=p;
		ridimensionaArray(p.dimensione);
		for(int i=0;i<dimensione;i++)
			array[i]=p.array[i];
	}
	return *this;
}

Polinomio::~Polinomio(){
	delete [] array;
}

unsigned int Polinomio::getGrado() const{
	return dimensione-1;
}

int Polinomio::getCoefficiente(unsigned int potenza) const{
	if(potenza >= dimensione)
		return 0;
	return array[potenza];
}

void Polinomio::setCoefficiente(unsigned int potenza, int c){
	if(potenza >= dimensione) 
		return;
	array[potenza]=c;
}

void Polinomio::setGrado(unsigned int grado) {
	if(dimensione!=grado+1){
		int* tmpArray=new int[grado+1];
		for(int i=0;i<grado+1;i++){
			if(i<dimensione)
				tmpArray[i]=array[i];
			else
				tmpArray[i]=0;
		}
		dimensione=grado+1;
		delete [] array;
		array=tmpArray;
	}
}

Polinomio Polinomio::operator+(const Polinomio& p) const{
	unsigned int dimThis=dimensione;
	unsigned int dimP=p.dimensione;
	unsigned int dimRisultato=dimThis;
	if(dimRisultato<dimP)
		dimRisultato=dimP;
	Polinomio risultato(dimRisultato-1);
	for(int i=0;i<dimRisultato;i++){
		int c=0;
		if(i<dimThis)
			c+=array[i];
		if(i<dimP)
			c+=p.array[i];
		risultato.array[i]=c;
		//risultato.setCoefficiente(i,c);
	}
	return risultato;
}

Polinomio& Polinomio::operator+=(const Polinomio& p){
	unsigned int dimP=p.dimensione;
	if(dimensione<dimP)
		setGrado(dimP-1);
	for(int i=0;i<dimensione;i++)
		if(i<dimP)
			array[i]+=p.array[i];
	return *this;
}



void Polinomio::stampa() const {
	/*for(int i=dimensione-1;i>=0;i--){
		int coefficiente=array[i];
		if(coefficiente==0){
			if(dimensione==1)
				cout<<coefficiente;
		}
		else if(coefficiente>0){
			cout<<"+";
			if(coefficiente!=1 || i==0)
				cout<<coefficiente;
		}
		else {
			cout<<"-";
			if(coefficiente!=-1 || i==0)
				cout<<coefficiente;
		}
		if(i>0){
			cout<<"p";
			if(i>1)
				cout<<"^"<<i;
		}
	}
	cout<<endl;*/
	cout<<(*this);
}

ostream& operator<<(ostream& out, const Polinomio& p){
	for(int i=p.dimensione-1;i>=0;i--){
		int coefficiente=p.array[i];
		if(coefficiente==0){
			if(p.dimensione==1)
				out<<coefficiente;
			continue;
		}
		else if(coefficiente>0){
			cout<<"+";
			if(coefficiente!=1 || i==0)
				out<<coefficiente;
		}
		else {
			out<<"-";
			if(coefficiente!=-1 || i==0)
				out<<coefficiente;
		}
		if(i>0){
			out<<"p";
			if(i>1)
				out<<"^"<<i;
		}
	}
	return out;
	
}

void Polinomio::leggi() {
	cin>>(*this);
}

istream& operator>>(istream& in, Polinomio& p){
	unsigned int grado=0;
	in>>grado;
	p.ridimensionaArray(grado+1);
	for(int i=0;i<p.dimensione;i++){
		int c=0;
		in>>c;
		p.array[i]=c;
	}
	return in;
}

void Polinomio::ridimensionaArray(unsigned int dim){
	if(dimensione!=dim)
	{
		dimensione=dim;
		delete [] array;
		array=new int[dimensione];
	}
}



