#ifndef POLINOMIO_H
#define POLINOMIO_H

#include <iostream>
using namespace std;

class Polinomio{
	friend ostream& operator<<(ostream& out, const Polinomio& p);
	friend istream& operator>>(istream& in, Polinomio& p);
	
	private:
		int* array;
		unsigned int dimensione;
		
		void ridimensionaArray(unsigned int dim);
		
	public:
		Polinomio(unsigned int grado);
		void setCoefficiente(unsigned int potenza, int c);
		int getCoefficiente(unsigned int potenza) const;
		void setGrado(unsigned int grado);
		unsigned int getGrado() const;
		Polinomio(const Polinomio& p);
		Polinomio& operator=(const Polinomio& p);
		~Polinomio();
		
		void stampa() const;
		void leggi();
		
		//Polinomio p(5);
		//Polinomio p1(3);
		//Polinomio p2=p.operator+(p1);
		Polinomio operator+(const Polinomio& p) const;
		//(p+=p1)+=p2;
		//p=p.operator+=(p1);
		Polinomio& operator+=(const Polinomio& p);
		
};

#endif