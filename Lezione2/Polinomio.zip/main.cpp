#include "Polinomio.h"

int main(){
	Polinomio pol1(6);
	pol1.setCoefficiente(2,5);
	cout<<"POLINOMIO 1:"<<endl;
	cout<<pol1<<endl;

	Polinomio pol2(6);
	pol2.setCoefficiente(2,2);
	cout<<"POLINOMIO 2:"<<endl;
	cout<<pol2<<endl;

	Polinomio pol3=pol1+pol2;
	cout<<"POLINOMIO 3, SOMMA DI POLINOMIO 1 E POLINOMIO 2:"<<endl;
	cout<<pol3<<endl;
	cout<<"I POLINOMI 1 e 2 SONO RIMASTI UGUALI:"<<endl;
	cout<<"POLINOMIO 1"<<endl;
	cout<<pol1<<endl;
	cout<<"POLINOMIO 2"<<endl;
	cout<<pol2<<endl;

	pol1.setGrado(8);
	pol1.setCoefficiente(7,2);
	cout<<"POLINOMIO 1 DOPO CAMBIO DI GRADO:"<<endl;
	cout<<pol1<<endl;

	pol1+=pol2;
	cout<<"POLINOMIO 1 DOPO += CON POLINOMIO 2:"<<endl;
	cout<<pol1<<endl;
	
	Polinomio pol5=pol2;
	cout<<"POLINOMIO 5, COPIA DI POLINOMIO 2:"<<endl;
	cout<<pol5<<endl;
	
	return 0;
}
