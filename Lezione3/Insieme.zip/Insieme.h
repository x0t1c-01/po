#ifndef INSIEME_H
#define INSIEME_H

#include <iostream>
using namespace std;

class Insieme{
	friend ostream& operator<<(ostream& out, const Insieme& p);
	friend istream& operator>>(istream& in, Insieme& p);
	
	private:
		bool* array;
		unsigned int dimensione;
		
		void ricopia(unsigned int dim);
		void azzera(unsigned int dim);
		
	public:
		Insieme();
		Insieme(unsigned int numeroMassimo);
		Insieme(const Insieme& p);
		~Insieme();
		Insieme& operator=(const Insieme& p);
		
		void stampa() const;
		void leggi();
		
		void aggiungiElemento(unsigned int n);
	
		Insieme unione(const Insieme& p) const;
		Insieme intersezione(const Insieme& p) const;
		Insieme operator+(const Insieme& p) const;
		Insieme& operator+=(const Insieme& p);
		Insieme operator-(const Insieme& p) const;
		Insieme& operator-=(const Insieme& p);
		
};

#endif