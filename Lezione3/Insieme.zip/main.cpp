#include "Insieme.h"

int main(){
	Insieme i1;
	i1.aggiungiElemento(2);
	i1.aggiungiElemento(7);
	
	cout<<"INSIEME 1:"<<endl;
	cout<<i1<<endl;

	Insieme i2(6);
	i2.aggiungiElemento(9);
	cout<<"INSIEME 2:"<<endl;
	cout<<i2<<endl;

	Insieme i3=i1+i2;
	cout<<"INSIEME 3, UNIONE DI INSIEME 1 E INSIEME 2:"<<endl;
	cout<<i3<<endl;
	cout<<"GLI INSIEMI 1 e 2 SONO RIMASTI UGUALI:"<<endl;
	cout<<"INSIEME 1"<<endl;
	cout<<i1<<endl;
	cout<<"INSIEME 2"<<endl;
	cout<<i2<<endl;

	i2.aggiungiElemento(8);
	cout<<"INSIEME 2 DOPO AGGIUNTA:"<<endl;
	cout<<i2<<endl;

	i2-=i1;
	cout<<"INSIEME 1 DOPO -= CON POLINOMIO 2:"<<endl;
	cout<<i2<<endl;
	
	Insieme i4=i1-i3;
	cout<<"INSIEME 4, INTERSEZIONE DI INSIEME 1 e INSIEME 3:"<<endl;
	cout<<i4<<endl;
	
	i4+=i1;
	cout<<"INSIEME 4 DOPO += CON POLINOMIO 1:"<<endl;
	cout<<i4<<endl;
	
	return 0;
}
