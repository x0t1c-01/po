#include "Insieme.h"

Insieme::Insieme(unsigned int numeroMassimo):dimensione(numeroMassimo){
	array=new bool[dimensione];
	for(int i=0;i<dimensione;i++)
		array[i]=false;
}


Insieme::Insieme():dimensione(1){
	array=new bool[dimensione];
	array[0]=false;
}

Insieme::Insieme(const Insieme& p):dimensione(p.dimensione){
	array=new bool[dimensione];
	for(int i=0;i<dimensione;i++)
		array[i]=p.array[i];
}

Insieme& Insieme::operator=(const Insieme& p){
	if(this!=&p){
		azzera(p.dimensione);
		for(int i=0;i<dimensione;i++)
			array[i]=p.array[i];
	}
	return *this;
}

Insieme::~Insieme(){
	delete [] array;
}

void Insieme::aggiungiElemento(unsigned int n){
	if(n >= dimensione)
		ricopia(n+1);
	array[n]=true;
}

Insieme Insieme::operator+(const Insieme& p) const{
	unsigned int dimThis=dimensione;
	unsigned int dimP=p.dimensione;
	unsigned int dimRisultato=dimThis;
	if(dimRisultato<dimP)
		dimRisultato=dimP;
	Insieme risultato(dimRisultato);
	for(int i=0;i<dimRisultato;i++){
		if((i<dimThis && array[i]) || (i<dimP && p.array[i]))
			risultato.array[i]=true;
	}
	return risultato;
}

Insieme& Insieme::operator+=(const Insieme& p){
	unsigned int dimP=p.dimensione;
	if(dimensione<dimP)
		ricopia(dimP);
	for(int i=0;i<dimP;i++)
		if(p.array[i])
			array[i]=true;
	return *this;
}

Insieme Insieme::operator-(const Insieme& p) const{
	unsigned int dimThis=dimensione;
	unsigned int dimP=p.dimensione;
	unsigned int dimRisultato=dimThis;
	if(dimRisultato<dimP)
		dimRisultato=dimP;
	Insieme risultato(dimRisultato);
	for(int i=0;i<dimRisultato;i++){
		if(i<dimThis && i<dimP && array[i] && p.array[i])
			risultato.array[i]=true;
		else
			risultato.array[i]=false;
	}
	return risultato;
}

Insieme& Insieme::operator-=(const Insieme& p){
	unsigned int dimP=p.dimensione;
	if(dimensione<dimP)
		ricopia(dimP);
	for(int i=0;i<dimensione;i++){
		if(i<dimensione && i<dimP && array[i] && p.array[i]){
			cout<<i<<array[i]<<p.array[i];
			array[i]=true;
		}
		else
			array[i]=false;
	}
	return *this;
}

Insieme Insieme::unione(const Insieme& p) const{
	return (*this+p);
}

Insieme Insieme::intersezione(const Insieme& p) const{
	return (*this-p);
}

void Insieme::stampa() const {
	cout<<(*this);
}

ostream& operator<<(ostream& out, const Insieme& p){
	out<<"{";
	bool primoElemento=false;
	for(int i=0;i<p.dimensione;i++){
		if(p.array[i]){
			if(!primoElemento) 
				primoElemento=true;
			else
				out<<" ,";
			out<<i;
		}
	}
	out<<"}";
	return out;
	
}

void Insieme::leggi() {
	cin>>(*this);
}

istream& operator>>(istream& in, Insieme& p){
	int n;
	in>>n;
	while(n!=-1)
		p.aggiungiElemento(n);
	return in;
}

void Insieme::ricopia(unsigned int dim){
	if(dimensione<dim)
	{
		bool* tmp=new bool[dim];
		for(int i=0;i<dim;i++){
			if(i<dimensione && array[i])
				tmp[i]=true;
			else
				tmp[i]=false;
		}
		dimensione=dim;
		delete [] array;
		array=tmp;
	}
}

void Insieme::azzera(unsigned int dim){
	if(dimensione<dim)
	{
		delete [] array;
		dimensione=dim;
		array=new bool[dimensione];
	}
	for(int i=0;i<dimensione;i++)
		array[i]=false;
}




