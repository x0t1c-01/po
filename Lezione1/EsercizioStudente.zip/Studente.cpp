#include "Studente.h"

Studente::Studente(const string& n, const string& c, int m){
	nome=n;
	cognome=c;
	matricola=m;
	esamiSuperati=0;
	for(int i=0;i<ESAMI_TOTALI;i++)
		esami[i]=0;
}

void Studente::aggiungiVoto(int voto){
	if(voto>=18 && voto<=31)
	{
		esami[esamiSuperati]=voto;
		esamiSuperati++;
	}
}

int Studente::calcolaMedia() const{
	if(esamiSuperati==0)
		return 0;
	int s=0;
	for(int i=0;i<esamiSuperati;i++)
		s+=esami[i]; // s=s+esami[i];
	return s/esamiSuperati;
}

int Studente::numeroEsamiMancanti() const{
	return ESAMI_TOTALI-esamiSuperati;
}

int Studente::numeroEsamiSuperati() const{
	return esamiSuperati;
}

ostream& operator<<(ostream& out, const Studente& s){
	out<<"Nome: "<<s.nome<<endl;
	out<<"Cognome: "<<s.cognome<<endl;
	out<<"Matricola: "<<s.matricola<<endl;
	out<<"Voti: "<<endl;
	for(int i=0;i<s.esamiSuperati;i++)
		out<<s.esami[i]<<endl;
	return out;
}