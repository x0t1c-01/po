#ifndef STUDENTE_H
#define STUDENTE_H

#include <iostream>
using namespace std;

const int ESAMI_TOTALI = 30;

class Studente{
	friend ostream& operator<<(ostream& out, const Studente& s);
private:
	string nome;
	string cognome;
	int matricola;
	int esami[ESAMI_TOTALI];
	int esamiSuperati;
public:
	Studente(const string& n, const string& c, int m);
	void aggiungiVoto(int voto);
	int calcolaMedia() const;
	int numeroEsamiMancanti() const;
	int numeroEsamiSuperati() const;
};

#endif