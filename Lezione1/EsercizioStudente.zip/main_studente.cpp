#include <iostream>
#include "Studente.h"
using namespace std;

int main(){
	Studente s("Mario","Rossi",123456);
	s.aggiungiVoto(28);
	s.aggiungiVoto(20);
	cout<<s<<endl;
	return 0;
}