#ifndef ESEMPIO_H
#define ESEMPIO_H

#include<iostream>
using namespace std;

class Esempio {
private:
	string* s1;
	string s2;
public:
  	Esempio(){
    		cout<<"Costruttore"<<endl;
    		s1=new string("ciao");
		s2="buonasera";
	}
	Esempio(const Esempio& e){
		cout<<"Costruttore copia"<<endl;
		s1=new string(*(e.s1));
		s2=e.s2;
	}
	~Esempio(){
		cout<<"Distruttore"<<endl;
		delete s1;
	}
	Esempio& operator=(const Esempio& e) {
		cout<<"Operator="<<endl;
		if(this!=&e){
			delete s1;
			s1=new string(*(e.s1));
			s2=e.s2;
		}
		return *this;
	}
};


#endif
