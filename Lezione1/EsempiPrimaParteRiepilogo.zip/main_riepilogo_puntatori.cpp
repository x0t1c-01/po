#include <iostream>
#include "Esempio.h"
using namespace std;

int main(){
	int a=5;
	cout<<a<<endl;
	cout<<&a<<endl;
	
	cout<<"------------"<<endl;
	int* b=new int(3);
	cout<<*b<<endl;
	cout<<b<<endl;
	cout<<&*b<<endl;
	cout<<&b<<endl;
	delete b;
	
	cout<<"------------"<<endl;
	b=&a;
	cout<<*b<<endl;
	cout<<b<<endl;
	cout<<&*b<<endl;
	cout<<&b<<endl;
	
	cout<<"------------"<<endl;
	int arrayStatico[4]={1,2,3,4};
	cout<<arrayStatico<<endl;
	cout<<&arrayStatico<<endl;
	for(int i=0;i<4;i++){
		cout<<arrayStatico[i]<<endl;
		cout<<&arrayStatico[i]<<endl;
	}

	cout<<"------------"<<endl;	
	int* arrayDinamico=new int[4];
	cout<<arrayDinamico<<endl;
	cout<<&*arrayDinamico<<endl;
	cout<<&arrayDinamico<<endl;
	for(int i=0;i<4;i++){
		arrayDinamico[i]=i;
		cout<<arrayDinamico[i]<<endl;
		cout<<&arrayDinamico[i]<<endl;
	}
	delete [] arrayDinamico;
	
	cout<<"------------"<<endl;	
	int** arrayDinamicoDiPuntatori=new int*[4];
	cout<<arrayDinamicoDiPuntatori<<endl;
	//cout<<&*arrayDinamicoDiPuntatori<<endl; 
	cout<<&arrayDinamicoDiPuntatori<<endl;
	for(int i=0;i<4;i++){
		arrayDinamicoDiPuntatori[i]=new int(i);
		cout<<*arrayDinamicoDiPuntatori[i]<<endl;
		//cout<<&*arrayDinamicoDiPuntatori[i]<<endl;
		cout<<arrayDinamicoDiPuntatori[i]<<endl;
		cout<<&arrayDinamicoDiPuntatori[i]<<endl;
	}
	for(int i=0;i<4;i++){
		delete arrayDinamicoDiPuntatori[i];
	}
	delete [] arrayDinamicoDiPuntatori;
	
	cout<<"------------"<<endl;	
	int** matriceDinamica=new int*[2];
	cout<<matriceDinamica<<endl;
	//cout<<&*matriceDinamica<<endl;
	cout<<&matriceDinamica<<endl;
	for(int i=0;i<2;i++){
		matriceDinamica[i]=new int[2];
		//cout<<&*matriceDinamica[i]<<endl;
		cout<<matriceDinamica[i]<<endl;
		cout<<&matriceDinamica[i]<<endl;
		for(int j=0;j<2;j++){
			matriceDinamica[i][j]=i*2+j;
			cout<<matriceDinamica[i][j]<<endl;
			cout<<&matriceDinamica[i][j]<<endl;
		}
	}
	for(int i=0;i<2;i++)
		delete [] matriceDinamica[i];
	delete [] matriceDinamica;
	
	cout<<"------------"<<endl;	
	Esempio e1;
	Esempio e2(e1);
	Esempio e3;
	e3=e1;
	Esempio* e4=new Esempio(e2);
	delete e4;
	e4=&e2;
	e4=new Esempio;
	delete e4;
	
	return 0;

}
