#include "GestoreComputers.h"
#include <climits>

/*
Calcolare il massimo delle medie dei prezzi dei computers prodotti da ogni produttore.

Utilizzare la divisione intera.

Se non sono presenti computers, restituire -1.
            
*/
int GestoreComputers::metodo1()
{	
	if(computers.empty())
		return -1;
	
	int max=-1;
	for(list<Computer>::iterator it=computers.begin();it!=computers.end();it++){
		string produttore=it->getProduttore();
		int somma=0, count=0;
		for(list<Computer>::iterator it2=computers.begin();it2!=computers.end();it2++){
			if(it2->getProduttore()==produttore){
				somma+=it2->getPrezzo();
				count++;
			}
		}
		//if(count>0){
			int media=somma/count;
			if(media>max)
				max=media;
		//}
	}
	
    return max;
}

/*
Determinare la mediana dei computers ottenuta considerando la seguente relazione d'ordine:

Un computer C1 precede un computer C2 se il prezzo di C1 e' minore del prezzo di C2 e a parita' di prezzo, 
il tipo di C1 precede il tipo di C2 (ULTRABOOK precede NETBOOK precede NOTEBOOK).

Restituire il prezzo del computer che si trova in corrispondenza della mediana.

Nel caso in cui non ci siano computers presenti nel gestore, restituire -1.

NOTA BENE: calcolare mediana nel seguente modo: dopo aver ordinato gli oggetti 
si prende quello presente nel mezzo (utilizzare la divisione intera). 
            
*/
int GestoreComputers::metodo2()
{
	if(computers.empty())
		return -1;
	
	list<Computer> ordinata;
    for(list<Computer>::iterator it=computers.begin();it!=computers.end();it++)
		ordinata.push_back(*it);
	ordinata.sort();
	
	int mediana=ordinata.size()/2,i=0;
	for(list<Computer>::iterator it=ordinata.begin();it!=ordinata.end();it++){
		if(i==mediana)
			return it->getPrezzo();
		i++;
	}

    return -1;
}

/*
Siano P1 e P2 produttori distinti tali per cui la somma dei prezzi di tutti i prodotti di P1 
meno la somma dei prezzi di tutti i prodotti di P2 e' minima rispetto ad ogni altra coppia di produttori.
Determinare la posizione del primo produttore tra P1 e P2 in ordine di occorrenza nell'elenco.

Se non sono presenti computers o e' presente un solo produttore, restituire -1.

NOTA BENE: nel caso ci siano piu' coppie di produttori distinti che verificano la condizione, 
considerare il primo produttore in ordine di occorrenza nell'elenco che si trova in una di queste coppie.
    
// Se la lista avesse 3 produttori: P1 con somma dei prezzi 10, P2 con somma dei prezzi 8 e P3 con somma dei prezzi 5, 
// la coppia da considerare sarebbe P1 e P3, perché si intende che 5-10=-5 è minore di 8-10=-2.	
*/
			
int GestoreComputers::metodo3()
{
	/*if(computers.empty())
		return -1;
	bool unSoloProduttore=true; 
	int posMin=0,posMax=0;
	int min=INT_MAX,max=INT_MIN;
	int i=0;
	for(list<Computer>::iterator it=computers.begin();it!=computers.end();it++,i++){
		string produttore=it->getProduttore();
		int somma=0;
		for(list<Computer>::iterator it2=computers.begin();it2!=computers.end();it2++){
			if(it2->getProduttore()==produttore)
				somma+=it2->getPrezzo();
			else 
				unSoloProduttore=false;
		}
		if(somma>max){
			max=somma;
			posMax=i;
		}
		if(somma<min){
			min=somma;
			posMin=i;
		}
	}
	if(unSoloProduttore) return -1;
	if(posMin<posMax)
		return posMin;
	return posMax;*/
	
	if(computers.empty())
		return -1;
	bool unSoloProduttore=true; 
	vector<string> produttori;
	vector<int> somme;
	for(list<Computer>::iterator it=computers.begin();it!=computers.end();it++){
		string produttore=it->getProduttore();
		int somma=0;
		for(list<Computer>::iterator it2=computers.begin();it2!=computers.end();it2++){
			if(it2->getProduttore()==produttore)
				somma+=it2->getPrezzo();
			else 
				unSoloProduttore=false;
		}
		somme.push_back(somma);
		produttori.push_back(produttore);
	}
	if(unSoloProduttore) return -1;
	int min=INT_MAX;
	int p1,p2;
	for(unsigned i=0;i<produttori.size();i++){
		for(unsigned j=0;j<produttori.size();j++){
			if(produttori[i]!=produttori[j] && (somme[i]-somme[j])<min){
				min=(somme[i]-somme[j]);
				p1=i;
				p2=j;
			}
		}
	}
	if(p1<p2)
		return p1;
	return p2;
}

/*
Data la seguente definizione:
Un computer C1 e' connesso con un Computer C2 se:
- C1 e' connesso con C2, oppure
- C1 e' connesso con C3 e C3 e' connesso con C2.

Il metodo deve restituire il numero massimo di computer connessi tra loro.

Nel caso in cui non ci siano computers restituisce -1.
            
*/

int GestoreComputers::metodo4()
{
    if(computers.empty())
		return -1;
	int max=0;
	for(list<Computer>::iterator it=computers.begin();it!=computers.end();it++){
		string c=it->getNomeComputer();
		list<string> visitati;
		list<string> daVisitare;
		daVisitare.push_back(c);
		while(!daVisitare.empty()){
			c=daVisitare.back();
			daVisitare.pop_back();
			visitati.push_back(c);
			for(list<Computer>::iterator it2=computers.begin();it2!=computers.end();it2++)
				if(c==it2->getNomeComputer() 
					&& find(daVisitare.begin(),daVisitare.end(),it2->getConnessoA()) == daVisitare.end()
					&& find(visitati.begin(),visitati.end(),it2->getConnessoA()) == visitati.end()){
					daVisitare.push_back(it2->getConnessoA());
				}
				/*if(c==it2->getNomeComputer()){
					bool presente=false;
					for(list<string>::iterator it3=visitati.begin();it3!=visitati.end()&&!presente;it3++){
						if(*it3==it2->getConnessoA())
							presente=true;
					}
					for(list<string>::iterator it3=daVisitare.begin();it3!=daVisitare.end()&&!presente;it3++){
						if(*it3==it2->getConnessoA())
							presente=true;
					}
					if(!presente)
						daVisitare.push_back(it2->getConnessoA());
				}*/
		}
		if(visitati.size()>max)
			max=visitati.size();
	}
	return max;
}


